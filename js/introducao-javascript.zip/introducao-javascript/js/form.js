var adicionarPaciente = document.querySelector('#adicionar-paciente');

adicionarPaciente.addEventListener('click', function(event){

    event.preventDefault();

    var form = document.querySelector("#form-adiciona");
    var paciente = obtemPacienteForm(form);
    var erros = validaPaciente(paciente);
    if(erros.length > 0){
        exibeMensagemErro(erros);
        return;
    }

    adicionaPacienteNaTabela(paciente);

    form.reset();
    var mensagemErro = document.querySelector("#mensagem-erro");
    mensagemErro.innerHTML = ""

})

function adicionaPacienteNaTabela(paciente){

    var pacienteTR = montaTr(paciente);
    let tbody = document.querySelector("#tabela-pacientes");
    tbody.appendChild(pacienteTR);

    
}


function obtemPacienteForm(form) {

    var paciente = {
        nome: document.querySelector("#nome").value,
        peso: parseFloat(
        document.querySelector("#peso").value.replace(",", ".")),
        altura: parseFloat(
        document.querySelector("#altura").value.replace(",", ".")),
        gordura: document.querySelector("#gordura").value,
        imc: calculaImc(
            parseFloat(document.querySelector("#peso").value.replace(",", ".")),
            parseFloat(document.querySelector("#altura").value.replace(",", ".")))
    }
    return paciente;
}

function montaTd(dado, classe){
    var td = document.createElement("td");
    td.textContent = dado;
    td.classList.add(classe);
    return td;
}

function montaTr(paciente){

    var pacienteTR = document.createElement("tr");
    pacienteTR.classList.add("paciente");

    var nomeTD = montaTd(paciente.nome, "info-nome");
    var pesoTD = montaTd(paciente.peso, "info-peso");
    var alturaTD = montaTd(paciente.altura, "info-altura");
    var gorduraTD = montaTd(paciente.gordura, "info-gordura");
    var imcTD = montaTd(paciente.imc, "info-imc");

    pacienteTR.appendChild(nomeTD);
    pacienteTR.appendChild(pesoTD);
    pacienteTR.appendChild(alturaTD);
    pacienteTR.appendChild(gorduraTD);
    pacienteTR.appendChild(imcTD);

    return pacienteTR;
}

function validaPaciente(paciente){

    var erros = [];

    if(!validaPeso(paciente.peso)) erros.push("Peso é inválido");
    if(!validaAltura(paciente.altura)) erros.push("Altura inválida");
    if(paciente.nome.length == 0) erros.push("O nome não pode ser em branco");
    if (paciente.gordura.length == 0) erros.push("A gordura não pode ser em branco");
    if(paciente.peso.length == 0) erros.push("O peso não pode ser em branco");
    if(paciente.altura.length == 0) erros.push("A altura não pode ser em branco");

    return erros;
}

function exibeMensagemErro(erros){
    var ul = document.querySelector("#mensagem-erro");
    ul.innerHTML = "";
    erros.forEach(function(erro){
        var li = document.createElement("li");
        li.textContent = erro;
        ul.appendChild(li);

    });

};
