var pacientes = document.querySelectorAll(".paciente");

for (let i=0; i< pacientes.length; i++){
    var paciente = pacientes[i];

    var peso = parseFloat(paciente.querySelector(`.info-peso`).textContent);
    var altura = parseFloat(paciente.querySelector(`.info-altura`).textContent);
    var imc = parseFloat(paciente.querySelector(`.info-imc`).textContent);

    calculaImc(peso, altura);
    var pesoValido = validaPeso(peso);
    var alturaValida = validaAltura(altura);

    paciente.querySelector(`.info-imc`).textContent = calculaImc(peso, altura);

    if (!pesoValido){
        paciente.querySelector(".info-imc").textContent = "Peso inválido";
        paciente.style.color = "red";
    }

    if (!alturaValida){
        paciente.querySelector(`.info-imc`).textContent = "Altura inválida";
        paciente.style.color = "red";
    }
}

function calculaImc(peso, altura){
    
    let imc = (peso / (altura*altura)).toFixed(1);
    return imc;
}

function validaPeso(peso){
    if (peso >= 0 && peso <700){
        return true;
    } else {
        return false;
    }
}

function validaAltura(altura){
    if (altura >= 0 && altura<3.00){
        return true;
    } else {
        return false;
    }
}

